<?php
 define('HOST','localhost');         //hostname
 define('USER','root');     //username
 define('PASS','');        //user password
 define('DB','u8885787_postumbasgo');  //database name
 
 $con = mysqli_connect('localhost','root','','u8885787_postumbasgo') or die('Unable to Connect');

?>