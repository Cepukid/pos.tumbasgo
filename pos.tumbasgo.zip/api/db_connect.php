<?php
 define('HOST','localhost');         //hostname
 define('USER','u8885787_tmbgo');     //username
 define('PASS','papatarmi');        //user password
 define('DB','u8885787_postumbasgo');  //database name
 
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

?>